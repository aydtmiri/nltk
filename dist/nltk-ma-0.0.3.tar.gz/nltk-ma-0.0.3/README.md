#nltk-ma

This implementation of [NLTK](http://www.nltk.org/) extends the collocation and concordance line functions.
